create view ver as
select `a`.`ENAME` AS `员工`,ifnull(`c`.`ENAME`, '无') AS `领导`
from (`dyl`.`emp` `a`
       left join `dyl`.`emp` `c` on ((`c`.`EMPNO` = `a`.`MGR`)));

